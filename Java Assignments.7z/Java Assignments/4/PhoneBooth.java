
class PhoneBooth{  
 synchronized void makeCall(int n){//synchronized method  
   for(int i=1;i<=5;i++){  
     System.out.println(n*i);  
     try{  
      Thread.sleep(500);  
     }catch(Exception e){System.out.println(e);}  
   }  
  
 }  
}  
  
class MyThread1 extends Thread{  
PhoneBooth t;  
MyThread1(Table t){  
this.t=t;  
}  
public void run(){  
t.makeCall(5);  
}  
  
}  
class MyThread2 extends Thread{  
PhoneBooth t;  
MyThread2(Table t){  
this.t=t;  
}  
public void run(){  
t.makeCall(100);  
}  
}  
  
 