/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    ArrayList < Integer > list = new ArrayList < Integer > ();
    for (int i = 1; i < 51; i++)
      {
	list.add (i);
      }
    Normal n = new Normal (list);
    n.start ();
    Odd o = new Odd (list);
    o.start ();
    Even e = new Even (list);
    e.start ();
  }
}
