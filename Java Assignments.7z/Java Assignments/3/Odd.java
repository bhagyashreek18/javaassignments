import java.util.*;
public class Odd extends Thread
{
  public ArrayList < Integer > list = new ArrayList < Integer > ();
   Odd (ArrayList < Integer > list1)
  {
    list = list1;
    
  }
  public void run ()
  {
     
     for (int i=0;i<list.size() ; i++) 
     {
         if(list.get(i) % 2 !=0)
         {
              System.out.println(list.get(i));
         }
         
     }

  }

}
