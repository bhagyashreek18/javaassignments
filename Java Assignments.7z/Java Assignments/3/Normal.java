import java.util.*;
public class Normal extends Thread
{
  public ArrayList < Integer > list = new ArrayList < Integer > ();
   Normal (ArrayList < Integer > list1)
  {
    this.list = list1;
    
  }
  public void run ()
  {

    for (int i = 0; i < list.size (); i++)
      {
	System.out.println (list.get (i));
      }

  }

}
