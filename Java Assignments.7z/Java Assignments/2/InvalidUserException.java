class InvalidUserException extends Exception 
{ 
    public InvalidUserException(String s) 
    { 
        
        super(s); 
    } 
} 