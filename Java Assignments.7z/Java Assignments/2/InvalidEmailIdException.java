class InvalidEmailIdException extends Exception 
{ 
    public InvalidEmailIdException(String s) 
    { 
        
        super(s); 
    } 
} 